$("#phone1").intlTelInput({defaultStyling: "inside"});
$("#phone2").intlTelInput({defaultStyling: "outside"});
$("#phone3").intlTelInput({defaultStyling: "outside"});