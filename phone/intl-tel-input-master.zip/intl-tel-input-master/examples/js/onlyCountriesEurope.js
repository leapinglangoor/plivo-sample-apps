$("#phone").intlTelInput({
  onlyCountries: ["al", "ad", "at", "by", "be", "ba", "bg", "hr", "cz", "dk", "ee",
  "fo", "fi", "fr", "de", "gi", "gr", "gg", "va", "hu", "is", "ie", "im", "it", "je",
  "lv", "li", "lt", "lu", "mk", "mt", "md", "mc", "me", "nl", "no", "pl", "pt", "xk",
  "ro", "ru", "sm", "rs", "sk", "si", "es", "sj", "se", "ch", "ua", "gb"]
});